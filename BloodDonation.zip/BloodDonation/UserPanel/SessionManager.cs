﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserPanel
{
    public class SessionManager
    {
        public static string LoggedInUser { get; set; } = "";
        public static string LoggedInUsername { get; set; }
        public static int LoggedInUserId { get; set; }

    }

}

